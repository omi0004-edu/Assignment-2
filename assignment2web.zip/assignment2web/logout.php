<?php

// Start the session to access session variables
session_start();

// Destroy the session, clearing all session variables and ending the user's session
session_destroy();

// Redirect the user to the "login.php" page after logging out
header("Location: login.php");
exit;

