<?php

// Database connection parameters
$host = "localhost";
$dbname = "login_db";
$username = "root";
$password = "";

// Create a new mysqli object to establish a database connection
$mysqli = new mysqli(hostname: $host,
                     username: $username,
                     password: $password,
                     database: $dbname);

// Check if there is a connection error with the database
if ($mysqli->connect_errno) {
    // If there is a connection error, terminate the script and display the error message
    die("Connection error: " . $mysqli->connect_error);
}

// Return the $mysqli object, making the database connection available for other parts of the application
return $mysqli;
