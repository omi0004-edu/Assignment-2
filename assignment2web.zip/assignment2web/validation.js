function validate(event) {
    // Prevents form submission
    event.preventDefault();

    // Reset the error messages
    resetErrorMessages();

    // Get form elements
    const emailInput = document.getElementById('email');
    const nameInput = document.getElementById('name');
    const passwordInput = document.getElementById('password');
    const passwordConfirmInput = document.getElementById('password_confirmation');

    // Validate name
    if (nameInput.value.length === 0) {
        showError('name', 'Name is required.');
    }

    // Validate email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(emailInput.value)) {
        showError('email', 'Email address should be in the format xyz@xyz.xyz.');
    }

    // Validate password
    if (passwordInput.value.length < 8 || !/[A-Za-z]/.test(passwordInput.value) || !/\d/.test(passwordInput.value)) {
        showError('password', 'Password must be at least 8 characters and contain at least one letter and one number.');
    }

    // Validate password confirmation
    if (passwordInput.value !== passwordConfirmInput.value) {
        showError('password_confirmation', 'Passwords do not match.');
    }

    // If there are no errors, submit the form
    if (!hasErrors()) {
        document.getElementById('signup').submit();
    }
}

function resetErrorMessages() {
    const errorMessages = document.querySelectorAll('.error-message');
    errorMessages.forEach(message => {
        message.innerHTML = '';
    });

    const inputFields = document.querySelectorAll('.error');
    inputFields.forEach(field => {
        field.classList.remove('error');
    });
}

function showError(field, message) {
    const errorField = document.getElementById(`${field}-error`);
    errorField.innerHTML = `&#10006; ${message}`; // Add the X symbol before the error message

    const inputField = document.getElementById(field);
    inputField.classList.add('error');
}

function hasErrors() {
    const errorFields = document.querySelectorAll('.error');
    return errorFields.length > 0;
}

// Add event listener to the form submit event
document.getElementById('signup').addEventListener('submit', validate);
