<?php

// Start the session to access session variables
session_start();

// Initialize the $user variable
$user = null;

// Check if the "user_id" session variable is set, indicating that the user is logged in
if (isset($_SESSION["user_id"])) {
    
    // Require the database connection file
    $mysqli = require __DIR__ . "/database.php";
    
    // SQL query to retrieve user data based on the user ID stored in the session
    $sql = "SELECT * FROM user
            WHERE id = {$_SESSION["user_id"]}";
            
    // Execute the SQL query and store the result in $result
    $result = $mysqli->query($sql);
    
    // Fetch the user data as an associative array from the query result
    $user = $result->fetch_assoc();
}

?>
<!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
    <style>
        /* Custom styles for the personalized greeting */
        .welcome-message {
            color: black;
            padding: 10px;
            text-align: center;
            font-size: 20px;
           
        }
    </style>
</head>
<body>
<header>
    <h1 class="logo">Rolandia Watches</h1>
    <nav class="navbar">
      <!-- actual navigation links go here -->
      <a href="index.html">Home</a>
      <a href="#contact">Contact</a>
      <?php if (isset($user)): ?>
        <!-- If the user is logged in, display the "Logout" link -->
        <a href="logout.php">Logout</a>
      <?php else: ?>
        <!-- If the user is not logged in, display the "Login" and "Sign Up" links -->
        <a href="login.php">Login</a>
        <a href="sign_up.html">Sign Up</a>
      <?php endif; ?>
    </nav>
</header>
<h1>Home</h1>
<div style="margin-top: 200px;" >
    <?php if (isset($user)): ?>
        <!-- If the user is logged in, display a personalized greeting -->
        <div class="welcome-message">
            <p>Hello <?= htmlspecialchars($user["name"]) ?></p>
            <!-- Provide a link to log out (logout.php) -->
            <p><a href="logout.php">Log out</a></p>
            <p><a href="index.html">Home</a></p>
        </div>
    <?php else: ?>
        <!-- If the user is not logged in, provide options to log in or sign up -->
        <h2 style="color: black;
            padding: 10px;
            text-align: center;
            font-size: 20px;"> Hello you are currently not signed in, please select one of the following options</h2>
        <p style="color: black;
            padding: 10px;
            text-align: center;
            font-size: 20px;"><a href="login.php">Log in</a> or <a href="sign_up.html">Sign up</a></p>
    <?php endif; ?>
</div>
</body>
</html>
