<?php
$host = 'localhost';
$port = '3306';
$username = 'root';
$password = '';
$database = 'assignment_two';

try {
    $conn = new mysqli($host,$username, $password, $database);
    // Rest of the code to interact with the database
} catch (mysqli_sql_exception $e) {
    die('Connection failed: ' . $e->getMessage());
}
echo "Hello world";
?>
