<?php

// Check if the "name" field is empty
if (empty($_POST["name"])) {
    die("Name is required"); // If empty, display an error message and terminate the script
}

// Check if the "email" field contains a valid email address
if (!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {
    die("Valid email is required"); // If invalid, display an error message and terminate the script
}

// Check if the "password" field is at least 8 characters long
if (strlen($_POST["password"]) < 8) {
    die("Password must be at least 8 characters"); // If less than 8 characters, display an error message and terminate the script
}

// Check if the "password" field contains at least one letter (case-insensitive)
if (!preg_match("/[a-z]/i", $_POST["password"])) {
    die("Password must contain at least one letter"); // If no letter found, display an error message and terminate the script
}

// Check if the "password" field contains at least one number
if (!preg_match("/[0-9]/", $_POST["password"])) {
    die("Password must contain at least one number"); // If no number found, display an error message and terminate the script
}

// Check if the "password" and "password_confirmation" fields match
if ($_POST["password"] !== $_POST["password_confirmation"]) {
    die("Passwords must match"); // If passwords do not match, display an error message and terminate the script
}

// Hash the password using the default algorithm
$password_hash = password_hash($_POST["password"], PASSWORD_DEFAULT);

// Require the database connection file
$mysqli = require __DIR__ . "/database.php";

// SQL query to check if the email already exists
$check_sql = "SELECT * FROM user WHERE email = ?";
$check_stmt = $mysqli->prepare($check_sql);
$check_stmt->bind_param("s", $_POST["email"]);
$check_stmt->execute();
$check_result = $check_stmt->get_result();

if ($check_result->num_rows > 0) {
    die("Email already taken"); // If email exists, display an error message and terminate the script
}

// SQL query to insert user data into the database
$sql = "INSERT INTO user (name, email, password_hash)
        VALUES (?, ?, ?)";

// Initialize a prepared statement
$stmt = $mysqli->stmt_init();

// Check if the statement preparation failed
if (!$stmt->prepare($sql)) {
    die("SQL error: " . $mysqli->error); // If preparation failed, display an error message and terminate the script
}

// Bind the parameters to the prepared statement
$stmt->bind_param("sss", $_POST["name"], $_POST["email"], $password_hash);

// Execute the prepared statement
if ($stmt->execute()) {
    // If successful, redirect to the signup-success.html page and terminate the script
    header("Location: signup-success.html");
    exit;
} else {
    // If execution failed, display a generic error message with the MySQL error and error number
    die("An error occurred: " . $mysqli->error);
}
