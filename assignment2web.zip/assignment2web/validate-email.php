<?php

// Require the database connection file to interact with the database
$mysqli = require __DIR__ . "/database.php";

/// Check if the email parameter is provided
if (isset($_GET["email"])) {
    $email = $_GET["email"];

    // Build a SQL query with prepared statement to check if the email exists in the "user" table
    $sql = "SELECT * FROM user WHERE email = ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    // Determine if the email is available by checking the number of rows in the result
    $is_available = $result->num_rows === 0;

    // Set the response content type to JSON
    header("Content-Type: application/json");

    // Return the result as a JSON object indicating whether the email is available or not
    echo json_encode(["available" => $is_available]);
} else {
    // If no email is provided in the request, return an error
    header("Content-Type: application/json");
    echo json_encode(["error" => "Email parameter not provided"]);
}

?>